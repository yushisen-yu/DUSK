//
// Created by fairy on 2024/9/22.
//

#ifndef FURINA_BASEINIT_HPP
#define FURINA_BASEINIT_HPP

#include "JYZQ_Conf.h"

void BaseInit();




#endif //FURINA_BASEINIT_HPP
