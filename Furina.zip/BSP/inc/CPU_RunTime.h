//
// Created by 34753 on 2024/10/7.
//

#ifndef FURINA_CPU_RUNTIME_H
#define FURINA_CPU_RUNTIME_H
#include "JYZQ_Conf.h"

#ifdef __cplusplus
extern "C" {
#endif

#if FreeRTOS_DEBUG
void ConfigureTimerForRunTimeStats();
#endif

#ifdef __cplusplus
}
#endif
#endif //FURINA_CPU_RUNTIME_H
