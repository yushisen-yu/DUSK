//
// Created by DV on 2024/11/17.
//

#ifndef FURINA_USART_H
#define FURINA_USART_H

#include "JYZQ_Conf.h"
/* 预编译命令 */
#ifdef USE_USART
// 头文件

#ifdef __cplusplus
extern "C" {
#endif
// 宏定义
// 变量

// 接口
void usart1_init() ;
#ifdef __cplusplus
}
#endif
/* 预编译命令 */
#endif
#endif //FURINA_USART_H