//
// Created by fairy on 2024/10/27 14:59.
//
#if 1
// 头文件
#include "component.hpp"
// 函数


#endif